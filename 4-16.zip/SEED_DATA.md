# How to Seed Assignments, Events, and Classes Data

This guide explains how to seed assignments, events, and classes data.

Since the Firebase seeding script has been removed during the migration to Supabase, data seeding is now handled through:

1. **Backend API**: Use your backend's seeding endpoints or database tools.
2. **Supabase Dashboard**: Use the Supabase web dashboard to insert data directly into your database tables.
3. **Custom Scripts**: Create new scripts using Supabase client or direct database access.

## Recommended Approaches

### Using Supabase Dashboard

1. Go to your Supabase project dashboard
2. Navigate to the Table Editor
3. Insert data directly into `assignments`, `events`, and `classes` tables

### Using Backend API

If your backend provides seeding endpoints:

```bash
# Example API calls (adjust to your actual endpoints)
curl -X POST http://your-backend/api/seed/assignments
curl -X POST http://your-backend/api/seed/events
curl -X POST http://your-backend/api/seed/classes
```

### Creating a New Seeding Script

If you need to create a new seeding script:

```javascript
// Example using Supabase client
import { supabase } from './src/config/supabase';

export const seedAssignments = async () => {
  const assignments = [
    // your assignment data
  ];
  
  const { data, error } = await supabase
    .from('assignments')
    .insert(assignments);
    
  if (error) throw error;
  return data;
};
```

## Data Structures

Ensure your data matches the expected table schemas in Supabase or your backend database.

