import React from "react";
import { NavigationContainer } from "@react-navigation/native";

import { UserProvider, useUser } from "./src/context/UserContext";
import AppNavigator from "./src/AppNavigator";
function AppContent() {
  const { loading } = useUser();

  // still IMPORTANT: block UI until auth is ready
  if (loading) return null;

  return (
    <NavigationContainer>
      <AppNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <UserProvider>
      <AppContent />
    </UserProvider>
  );
}