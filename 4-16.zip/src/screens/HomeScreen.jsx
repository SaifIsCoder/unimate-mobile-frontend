

import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useUser } from "../context/UserContext";
import UserDrawer from "../components/UserDrawer";
import API_ENDPOINTS from "../config/api";
import { apiRequest } from "../services/apiClient";
import { scheduleNotification, requestPermissions } from "../services/notificationService";

import { classes as mockClasses } from "../data/index";
import { events as mockEvents } from "../data/events";
import mockAssignments from "../data/assignments.json";

const defaultAvatar = require("../../assets/avatar.jpg");

export default function HomeScreen({ navigation }) {
  const { user } = useUser();
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [todayClasses, setTodayClasses] = useState([]);
  const [stats, setStats] = useState({
    attendance: user?.attendance || "90",
    pendingAssignments: 0,
    upcomingQuizzes: 0,
  });
  const [nextEvent, setNextEvent] = useState(null);

  const handleBellPress = async () => {
    // Navigate to notifications screen
    navigation?.navigate("Notifications");
    
    // Also trigger a notification
    await scheduleNotification(
      "New Updates Available",
      "Check your assignments and schedule for today.",
      { type: "bell_press", screen: "Notifications" }
    );
  };

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    loadHomeData();
    requestPermissions();

    const timer = setTimeout(() => {
      scheduleNotification(
        "Welcome to uniMate!",
        "You have new updates. Check your assignments and schedule.",
        { type: "welcome" }
      );
    }, 5000);

    return () => {
      clearTimeout(timer);
    };
  }, [user]);

  const loadHomeData = async () => {
    try {
      setLoading(true);
      // const [classesRes, assignmentsRes, submissionsRes, attendanceRes, eventsRes] = await Promise.all([
      //   apiRequest(API_ENDPOINTS.CLASSES.ALL),
      //   apiRequest(API_ENDPOINTS.ASSIGNMENTS.MY),
      //   apiRequest(API_ENDPOINTS.ASSIGNMENTS.MY_SUBMISSIONS),
      //   apiRequest(API_ENDPOINTS.ATTENDANCE.MY),
      //   apiRequest(API_ENDPOINTS.EVENTS.ALL),
      // ]);

      // Hardcoded data substitution
      const classesData = mockClasses || [];
      const assignmentsData = mockAssignments.assignments || [];
      const attendanceData = Array(20).fill({ record: { status: "present" } }); // dummy attendance
      const eventsData = mockEvents || [];

      setTodayClasses(classesData);

      const pendingCount = assignmentsData.filter((a) => a.status === "Pending").length;

      const totalAttendance = attendanceData.length;
      const presentAttendance = attendanceData.filter((entry) => {
        const status = entry?.record?.status;
        return status === "present" || status === "late";
      }).length;
      const attendanceRate =
        totalAttendance > 0 ? Math.round((presentAttendance / totalAttendance) * 100) : 100;

      const upcomingEvents = eventsData; // Already mocked

      setStats({
        attendance: attendanceRate.toString(),
        pendingAssignments: pendingCount,
        upcomingQuizzes: 0,
      });
      setNextEvent(upcomingEvents[0] || null);
    } catch (error) {
      console.error("Error loading home data:", error);
      Alert.alert("Error", error.message || "Failed to load data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadHomeData();
  };

  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#6366F1" />
        </View>
      </SafeAreaView>
    );
  }

  // if (loading && !refreshing) {
  //   return (
  //     <SafeAreaView style={styles.safe}>
  //       <View style={styles.loadingContainer}>
  //         <ActivityIndicator size="large" color="#6366F1" />
  //       </View>
  //     </SafeAreaView>
  //   );
  // }
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* ================= HEADER ================= */}
        <View style={styles.header}>
          <View>
            <Text style={styles.welcome}>Welcome back</Text>
            <Text style={styles.name}>
              {user?.profile?.fullName || user?.email || "Student"}
            </Text>
            {user?.role && (
              <Text style={styles.degree}>{user.role.toUpperCase()}</Text>
            )}
            {/* <Text style={styles.motivation}>
              Move forward. One class at a time.
            </Text> */}
          </View>

          <View style={styles.headerIcons}>
            <TouchableOpacity
              style={styles.iconBtn}
              onPress={handleBellPress}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Ionicons name="notifications-outline" size={25} color="#0F172A" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.iconBtn}
              onPress={() => setDrawerVisible(true)}
            >
              <Image
                source={user?.profile?.avatarUrl ? { uri: user?.profile?.avatarUrl } : defaultAvatar}
                style={styles.avatar}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Seed Data Button - Remove in production */}
        {/* {__DEV__ && (
          <TouchableOpacity
            style={[styles.seedButton, seeding && styles.seedButtonDisabled]}
            onPress={handleSeedData}
            disabled={seeding}
          >
            {seeding ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <Ionicons name="cloud-upload-outline" size={18} color="#FFFFFF" />
                <Text style={styles.seedButtonText}>Seed Data to Firebase</Text>
              </>
            )}
          </TouchableOpacity>
        )} */}

        {/* ================= TODAY HERO CARD ================= */}
        <TouchableOpacity 
          onPress={() => navigation?.navigate("Schedule")}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={["#6366F1", "#8B5CF6", "#A855F7"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.heroCard}
          >
            <View style={styles.heroTitleContainer}>
              <View style={styles.heroTitleIconContainer}>
            <Ionicons name="calendar-outline" size={20} color="#FFFFFF" />
              <Text style={styles.heroTitle}>Today</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#FFFFFF" style={{ opacity: 0.9 }} />
            </View>
            <Text style={styles.heroMain}>
              {todayClasses.length > 0 ? `${todayClasses.length} class${todayClasses.length > 1 ? 'es' : ''} scheduled` : "No classes scheduled"}
            </Text>
            <Text style={styles.heroSub}>
              {todayClasses.length > 0 ? "Tap to view schedule" : "You have time to plan ahead"}
            </Text>
          </LinearGradient>
          </TouchableOpacity>

        {/* ================= PROGRESS SNAPSHOT ================= */}
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.statCard}
            onPress={() => alert("Attendance details")}
          >
            <Ionicons name="stats-chart-outline" size={22} color="#6366F1" />
            <Text style={styles.cardTitle}>Attendance</Text>
            <Text style={styles.cardValue}>{stats.attendance}%</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.statCard}
            onPress={() => navigation?.navigate("Assignments")}
          >
            <Ionicons name="document-text-outline" size={22} color="#6366F1" />
            <Text style={styles.cardTitle}>Assignments</Text>
            <Text style={styles.cardValue}>{stats.pendingAssignments} pending</Text>
          </TouchableOpacity>
        </View>

        {/* ================= SECONDARY INFO ================= */}
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.statCard}
            onPress={() => alert("Quizzes screen coming soon")}
          >
            <Ionicons name="help-circle-outline" size={22} color="#6366F1" />
            <Text style={styles.cardTitle}>Quizzes</Text>
            <Text style={styles.cardValue}>{stats.upcomingQuizzes > 0 ? `${stats.upcomingQuizzes} upcoming` : "No upcoming"}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.statCard}
            onPress={() => navigation?.navigate("Events")}
          >
            <Ionicons name="gift-outline" size={22} color="#6366F1" />
            <Text style={styles.cardTitle}>Next Event</Text>
            <Text style={styles.cardValue} numberOfLines={1}>
              {nextEvent?.title || nextEvent?.name || "No events"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* ================= BOTTOM SPACE ================= */}
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Drawer Component */}
      <UserDrawer
        visible={drawerVisible}
        onClose={() => setDrawerVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  container: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  avatar: {
    width: 43,
    height: 43,
    borderRadius: 50,
  },

  /* HEADER */
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  welcome: {
    fontSize: 12,
    color: "#64748B",
  },
  name: {
    fontSize: 22,
    fontWeight: "600",
    color: "#0F172A",
  },
  degree: {
    fontSize: 14,
    color: "#475569",
    marginTop: 2,
  },
  motivation: {
    fontSize: 13,
    color: "#6366F1",
    marginTop: 6,
  },
  headerIcons: {
    flexDirection: "row",
    alignItems: "center",
  },
  iconBtn: {
    marginLeft: 12,
  },
  seedButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#6366F1",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 20,
    gap: 8,
  },
  seedButtonDisabled: {
    opacity: 0.6,
  },
  seedButtonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "600",
  },

  /* HERO CARD */
  heroCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  heroTitleContainer: {
    flexDirection: "row",
    alignItems: "center",
    // gap: 6,
    justifyContent: "space-between",
    // marginTop: 10,
  },
  heroTitleIconContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  heroTitle: {
    fontSize: 18,
    color: "#FFFFFF",
    opacity: 0.9,
    fontWeight: "600",
  },
  heroMain: {
    fontSize: 17,
    fontWeight: "600",
    color: "#FFFFFF",
    marginTop: 6,
  },
  heroSub: {
    fontSize: 14,
    color: "#FFFFFF",
    marginTop: 4,
    opacity: 0.85,
  },

  /* GRID */
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  statCard: {
    backgroundColor: "#FFFFFF",
    width: "48%",
    borderRadius: 16,
    padding: 16,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 14,
    color: "#475569",
    marginTop: 10,
  },
  cardValue: {
    fontSize: 18,
    fontWeight: "600",
    color: "#0F172A",
    marginTop: 6,
  },
});
