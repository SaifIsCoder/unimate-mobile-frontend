import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useEffect } from "react";
import Header from "../components/Header";
import API_ENDPOINTS from "../config/api";
import { apiRequest } from "../services/apiClient";

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      // const response = await apiRequest(API_ENDPOINTS.ANNOUNCEMENTS.ALL);
      // const data = response?.data || [];

      // Hardcoded data
      const data = [
        {
          _id: "n1",
          title: "Exam Schedule Released",
          message: "The final exam schedule has been posted on the dashboard.",
          scope: "University",
          readAt: null,
          createdAt: new Date().toISOString()
        },
        {
          _id: "n2",
          title: "Maintenance Downtime",
          message: "Unimate portal will be down for maintenance from 2 AM to 4 AM.",
          scope: "General",
          readAt: new Date().toISOString(),
          createdAt: new Date(Date.now() - 86400000).toISOString()
        }
      ];

      const mapped = data.map((announcement) => ({
        id: announcement._id,
        title: announcement.title,
        message: announcement.message,
        type: announcement.scope ? announcement.scope.toUpperCase() : "GENERAL",
        isRead: Boolean(announcement.readAt),
        timestamp: announcement.createdAt,
      }));

      setNotifications(mapped);
    } catch (error) {
      console.error("Error loading announcements:", error);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id) => {
    try {
      // await apiRequest(API_ENDPOINTS.ANNOUNCEMENTS.MARK_READ(id), { method: "PATCH" });
      setNotifications((prev) =>
        prev.map((notif) => (notif.id === id ? { ...notif, isRead: true } : notif))
      );
    } catch (error) {
      console.error("Error marking announcement read:", error);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#1E88E5" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Header />
      <View>
      {notifications.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🔔</Text>
          <Text style={styles.emptyTitle}>No notifications</Text>
          <Text style={styles.emptySubtitle}>
            You're all caught up!
          </Text>
        </View>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.card, !item.isRead && styles.unreadCard]}
              onPress={() => !item.isRead && markAsRead(item.id)}
            >
              <Text style={styles.noteTitle}>{item.title}</Text>
              <Text style={styles.noteMsg}>{item.message}</Text>
              {item.type && (
                <Text style={styles.noteType}>{item.type}</Text>
              )}
              {!item.isRead && <View style={styles.unreadDot} />}
            </TouchableOpacity>
          )}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 100,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
    color: "#374151",
  },
  emptySubtitle: {
    fontSize: 14,
    color: "#6B7280",
  },
  card: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    position: "relative",
    borderColor: "#E5E7EB",
    borderWidth: 1,
  },
  unreadCard: {
    backgroundColor: "#F0F9FF",
    borderLeftWidth: 4,
    borderLeftColor: "#1E88E5",
  },
  noteTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#111827",
    marginBottom: 4,
  },
  noteMsg: {
    fontSize: 14,
    color: "#6B7280",
    marginBottom: 4,
  },
  noteType: {
    fontSize: 12,
    color: "#9CA3AF",
    marginTop: 4,
  },
  unreadDot: {
    position: "absolute",
    top: 15,
    right: 15,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#1E88E5",
  },
});
