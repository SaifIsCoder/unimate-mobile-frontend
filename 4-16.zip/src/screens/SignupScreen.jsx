import React, { useState } from "react";
import {
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { registerUser } from "../services/authService";
import { useUser } from "../context/UserContext";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const STRONG_PASSWORD_REGEX =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

export default function SignupScreen({ navigation }) {
  const [fullName, setFullName] = useState("");
  const [tenantCode, setTenantCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState("");

  const { setUser, clearAuthError } = useUser();

  const validateForm = () => {
    const normalizedEmail = email.trim().toLowerCase();

    if (!fullName.trim() || !tenantCode.trim() || !normalizedEmail || !password) {
      return "Full name, university code, email, and password are required.";
    }

    if (!EMAIL_REGEX.test(normalizedEmail)) {
      return "Please enter a valid email address.";
    }

    if (password !== confirmPassword) {
      return "Password and confirm password do not match.";
    }

    if (!STRONG_PASSWORD_REGEX.test(password)) {
      return "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
    }

    return null;
  };

  const handleSignup = async () => {
    const validationError = validateForm();
    if (validationError) {
      setFormError(validationError);
      return;
    }

    setLoading(true);
    setFormError("");
    clearAuthError();

    try {
      // const result = await registerUser({
      //   email: email.trim(),
      //   password,
      //   fullName: fullName.trim(),
      //   tenantCode: tenantCode.trim(),
      // });
      const result = {
        autoLoggedIn: true,
        user: {
          _id: "mock_user",
          email: email.trim(),
          role: "student",
          profile: {
            fullName: fullName.trim(),
            phone: "0000000000",
            avatarUrl: "https://i.pravatar.cc/150?img=12"
          }
        },
        message: "Account created successfully."
      };

      if (result?.autoLoggedIn && result?.user) {
        await setUser(result.user);

        Alert.alert("Success", result.message || "Account created successfully.");
        navigation.replace("MainTabs");
        return;
      }

      Alert.alert(
        "Success",
        result?.message ||
          "Account created successfully. Please login after activation.",
        [{ text: "OK", onPress: () => navigation.replace("Login") }]
      );
    } catch (error) {
      console.error("Signup error:", error);
      const message =
        error?.message ||
        "Unable to connect to server. Please check your connection.";
      setFormError(message);
      Alert.alert("Signup Failed", message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Create Student Account</Text>

      <TextInput
        placeholder="Full Name *"
        value={fullName}
        onChangeText={(value) => {
          setFullName(value);
          if (formError) setFormError("");
        }}
        style={styles.input}
      />

      <TextInput
        placeholder="University Code *"
        value={tenantCode}
        onChangeText={(value) => {
          setTenantCode(value);
          if (formError) setFormError("");
        }}
        autoCapitalize="characters"
        style={styles.input}
      />

      <TextInput
        placeholder="Email *"
        value={email}
        onChangeText={(value) => {
          setEmail(value);
          if (formError) setFormError("");
        }}
        keyboardType="email-address"
        autoCapitalize="none"
        style={styles.input}
      />

      <TextInput
        placeholder="Password *"
        secureTextEntry
        value={password}
        onChangeText={(value) => {
          setPassword(value);
          if (formError) setFormError("");
        }}
        style={styles.input}
      />

      <TextInput
        placeholder="Confirm Password *"
        secureTextEntry
        value={confirmPassword}
        onChangeText={(value) => {
          setConfirmPassword(value);
          if (formError) setFormError("");
        }}
        style={styles.input}
      />

      {!!formError && <Text style={styles.errorText}>{formError}</Text>}

      <TouchableOpacity
        style={styles.button}
        onPress={handleSignup}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Sign Up</Text>
        )}
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Login")}>
        <Text style={styles.link}>Already have an account? Login</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#1E88E5",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    height: 50,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 10,
  },
  button: {
    width: "100%",
    height: 50,
    backgroundColor: "#1E88E5",
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  buttonText: { color: "white", fontSize: 18, fontWeight: "bold" },
  link: { color: "#1E88E5", marginTop: 10 },
  errorText: {
    width: "100%",
    marginBottom: 12,
    color: "#D32F2F",
    fontSize: 13,
  },
});
